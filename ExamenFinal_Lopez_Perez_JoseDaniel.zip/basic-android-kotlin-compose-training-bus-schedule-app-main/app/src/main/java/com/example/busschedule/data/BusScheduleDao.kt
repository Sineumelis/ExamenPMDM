/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.busschedule.data

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Proporciona acceso a operaciones de lectura/escritura en la tabla de programación.
 * Utilizado por los ViewModel para formatear
 * los resultados de la consulta para su uso en la interfaz de usuario.
 */
@Dao
interface BusScheduleDao {
    @Query(
        """
        SELECT * FROM bus_schedule 
        ORDER BY arrival_time ASC    
        """
    )
    fun getAll(): Flow<List<BusSchedule>>

    @Query(
        """
        SELECT * FROM bus_schedule 
        WHERE stop_name = :stopName 
        ORDER BY arrival_time ASC 
        """
    )
    fun getByStopName(stopName: String): Flow<List<BusSchedule>>

    //Añado 3ª Query con nombres de llegada
    @Query(
        """
        SELECT * FROM bus_schedule 
        WHERE arrival_name = :arrivalName 
        ORDER BY arrival_name ASC 
        """
    )
    fun getByArrivalName(arrivalName: String): Flow<List<BusSchedule>>

    //Añado 4ª Query con id
    @Query(
        """
        SELECT * FROM bus_schedule 
        WHERE id = :id 
        ORDER BY id ASC 
        """
    )
    fun getById(id: String): Flow<List<BusSchedule>>

    //añado la 5ª Query que me los dará en orden inverso
    @Query(
        """
        SELECT * FROM bus_schedule 
        ORDER BY arrival_time DESC   
        """
    )
    fun getAllReverse(): Flow<List<BusSchedule>>
}